﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace pyatnashki
{   
    public partial class Game : Form
    {
        public static Random rnd = new Random();

        public static string[] arr = { "", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15" };

        public static string[] arr2 = { "", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15" };

        public Game()
        {
            InitializeComponent();

            Rand();

            button1.Text = arr[0];
            button2.Text = arr[1];
            button3.Text = arr[2];
            button4.Text = arr[3];
            button5.Text = arr[4];
            button6.Text = arr[5];
            button7.Text = arr[6];
            button8.Text = arr[7];
            button9.Text = arr[8];
            button10.Text = arr[9];
            button11.Text = arr[10];
            button12.Text = arr[11];
            button13.Text = arr[12];
            button14.Text = arr[13];
            button15.Text = arr[14];
            button16.Text = arr[15];


            if (button1.Text == "")
            {
                button1.Select();
                Button1();
             }

            if (button2.Text == "")
            {
                button2.Select();
                Button2();
            }

            if (button3.Text == "")
            {
                button3.Select();
                Button3();
            }

            if (button4.Text == "")
            {
                button4.Select();
                Button4();
            }

            if (button5.Text == "")
            {
                button5.Select();
                Button5();
            }

            if (button6.Text == "")
            {
                button6.Select();
                Button6();
            }

            if (button7.Text == "")
            {
                button7.Select();
                Button7();
            }

            if (button8.Text == "")
            {
                button8.Select();
                 Button8();
            }

            if (button9.Text == "")
            {
                button9.Select();
                Button9();
            }

            if (button10.Text == "")
            {
                button10.Select();
                Button10();
            }

            if (button11.Text == "")
            {
                button11.Select();
                Button11();
            }

            if (button12.Text == "")
            {
                button12.Select();
                Button12();
            }

            if (button13.Text == "")
            {
                button13.Select();
                Button13();
            }

            if (button14.Text == "")
            {
                button14.Select();
                Button14();
            }

            if (button15.Text == "")
            {
                button15.Select();
                Button15();
            }

            if (button16.Text == "")
            {
                button16.Select();
                Button16();
            }
        }

        public static void Rand()
        {
            string tmp = "";

            for (int i = 0; i < arr.Length - 1; i++)
            {
                    tmp = arr[i];
                    int k = rnd.Next(i + 1, arr.Length - 1);
                    arr[i] = arr[k];
                    arr[k] = tmp;
            }
        }

        public void Finish(Button b1, Button b2, Button b3, Button b4, Button b5, Button b6, Button b7, Button b8, Button b9, Button b10, Button b11, Button b12, Button b13, Button b14, Button b15, Button b16)
        {            
            if (b1.Text == arr2[0] && b2.Text == arr2[1] && b3.Text == arr2[2] && b4.Text == arr2[3] && b5.Text == arr2[4] && b6.Text == arr2[5] && b7.Text == arr2[6] && b8.Text == arr2[7] && b9.Text == arr2[8] && b10.Text == arr2[9] && b11.Text == arr2[10]&& b12.Text == arr2[11]&& b13.Text == arr2[12]&& b14.Text == arr2[13]&& b15.Text == arr2[14]&& b16.Text == arr2[15])
            {
                MessageBox.Show("You are Winner !!!");
            }
            
        }

        public void Button1()
        {
                button1.Enabled = true;
                button2.Enabled = true;
                button3.Enabled = false;
                button4.Enabled = false;
                button5.Enabled = true;
                button6.Enabled = false;
                button7.Enabled = false;
                button8.Enabled = false;
                button9.Enabled = false;
                button10.Enabled = false;
                button11.Enabled = false;
                button12.Enabled = false;
                button13.Enabled = false;
                button14.Enabled = false;
                button15.Enabled = false;
                button16.Enabled = false;
                
        }

        public void Button2()
        {
            button1.Enabled = true;
            button2.Enabled = true;
            button3.Enabled = true;
            button4.Enabled = false;
            button5.Enabled = false;
            button6.Enabled = true;
            button7.Enabled = false;
            button8.Enabled = false;
            button9.Enabled = false;
            button10.Enabled = false;
            button11.Enabled = false;
            button12.Enabled = false;
            button13.Enabled = false;
            button14.Enabled = false;
            button15.Enabled = false;
            button16.Enabled = false;
        }

        public void Button3()
        {
            button1.Enabled = false;
            button2.Enabled = true;
            button3.Enabled = true;
            button4.Enabled = true;
            button5.Enabled = false;
            button6.Enabled = false;
            button7.Enabled = true;
            button8.Enabled = false;
            button9.Enabled = false;
            button10.Enabled = false;
            button11.Enabled = false;
            button12.Enabled = false;
            button13.Enabled = false;
            button14.Enabled = false;
            button15.Enabled = false;
            button16.Enabled = false;
        }

        public void Button4()
        {
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = true;
            button4.Enabled = true;
            button5.Enabled = false;
            button6.Enabled = false;
            button7.Enabled = false;
            button8.Enabled = true;
            button9.Enabled = false;
            button10.Enabled = false;
            button11.Enabled = false;
            button12.Enabled = false;
            button13.Enabled = false;
            button14.Enabled = false;
            button15.Enabled = false;
            button16.Enabled = false;
        }

        public void Button5()
        {
            button1.Enabled = true;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = true;
            button6.Enabled = true;
            button7.Enabled = false;
            button8.Enabled = false;
            button9.Enabled = true;
            button10.Enabled = false;
            button11.Enabled = false;
            button12.Enabled = false;
            button13.Enabled = false;
            button14.Enabled = false;
            button15.Enabled = false;
            button16.Enabled = false;
        }

        public void Button6()
        {
            button1.Enabled = false;
            button2.Enabled = true;
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = true;
            button6.Enabled = true;
            button7.Enabled = true;
            button8.Enabled = false;
            button9.Enabled = false;
            button10.Enabled = true;
            button11.Enabled = false;
            button12.Enabled = false;
            button13.Enabled = false;
            button14.Enabled = false;
            button15.Enabled = false;
            button16.Enabled = false;
        }
        public void Button7()
        {
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = true;
            button4.Enabled = false;
            button5.Enabled = false;
            button6.Enabled = true;
            button7.Enabled = true;
            button8.Enabled = true;
            button9.Enabled = false;
            button10.Enabled = false;
            button11.Enabled = true;
            button12.Enabled = false;
            button13.Enabled = false;
            button14.Enabled = false;
            button15.Enabled = false;
            button16.Enabled = false;
        }
        public void Button8()
        {
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = true;
            button5.Enabled = false;
            button6.Enabled = false;
            button7.Enabled = true;
            button8.Enabled = true;
            button9.Enabled = false;
            button10.Enabled = false;
            button11.Enabled = false;
            button12.Enabled = true;
            button13.Enabled = false;
            button14.Enabled = false;
            button15.Enabled = false;
            button16.Enabled = false;
        }

        public void Button9()
        {
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = true;
            button6.Enabled = false;
            button7.Enabled = false;
            button8.Enabled = false;
            button9.Enabled = true;
            button10.Enabled = true;
            button11.Enabled = false;
            button12.Enabled = false;
            button13.Enabled = true;
            button14.Enabled = false;
            button15.Enabled = false;
            button16.Enabled = false;
        }

        public void Button10()
        {
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;
            button6.Enabled = true;
            button7.Enabled = false;
            button8.Enabled = false;
            button9.Enabled = true;
            button10.Enabled = true;
            button11.Enabled = true;
            button12.Enabled = false;
            button13.Enabled = false;
            button14.Enabled = true;
            button15.Enabled = false;
            button16.Enabled = false;
        }

        public void Button11()
        {
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;
            button6.Enabled = false;
            button7.Enabled = true;
            button8.Enabled = false;
            button9.Enabled = false;
            button10.Enabled = true;
            button11.Enabled = true;
            button12.Enabled = true;
            button13.Enabled = false;
            button14.Enabled = false;
            button15.Enabled = true;
            button16.Enabled = false;
        }

        public void Button12()
        {
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;
            button6.Enabled = false;
            button7.Enabled = false;
            button8.Enabled = true;
            button9.Enabled = false;
            button10.Enabled = false;
            button11.Enabled = true;
            button12.Enabled = true;
            button13.Enabled = false;
            button14.Enabled = false;
            button15.Enabled = false;
            button16.Enabled = true;
        }

        public void Button13()
        {
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;
            button6.Enabled = false;
            button7.Enabled = false;
            button8.Enabled = false;
            button9.Enabled = true;
            button10.Enabled = false;
            button11.Enabled = false;
            button12.Enabled = false;
            button13.Enabled = true;
            button14.Enabled = true;
            button15.Enabled = false;
            button16.Enabled = false;
        }

        public void Button14()
        {
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;
            button6.Enabled = false;
            button7.Enabled = false;
            button8.Enabled = false;
            button9.Enabled = false;
            button10.Enabled = true;
            button11.Enabled = false;
            button12.Enabled = false;
            button13.Enabled = true;
            button14.Enabled = true;
            button15.Enabled = true;
            button16.Enabled = false;
        }

        public void Button15()
        {
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;
            button6.Enabled = false;
            button7.Enabled = false;
            button8.Enabled = false;
            button9.Enabled = false;
            button10.Enabled = false;
            button11.Enabled = true;
            button12.Enabled = false;
            button13.Enabled = false;
            button14.Enabled = true;
            button15.Enabled = true;
            button16.Enabled = true;
        }

        public void Button16()
        {
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;
            button6.Enabled = false;
            button7.Enabled = false;
            button8.Enabled = false;
            button9.Enabled = false;
            button10.Enabled = false;
            button11.Enabled = false;
            button12.Enabled = true;
            button13.Enabled = false;
            button14.Enabled = false;
            button15.Enabled = true;
            button16.Enabled = true;
        }
        public string tmp = null;
       

        private void button1_Click(object sender, EventArgs e)
        {
            Button1();

            if (button2.Text == "")
            {
                tmp = button2.Text;
                button2.Text = button1.Text;
                button1.Text = tmp;
            }

            if (button5.Text == "")
            {
                tmp = button5.Text;
                button5.Text = button1.Text;
                button1.Text = tmp;
            }
            Finish(button1, button2, button3, button4, button5, button6, button7, button8, button9, button10, button11, button12, button13, button14, button15, button16);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Button2();

            if (button1.Text == "")
            {
                tmp = button1.Text;
                button1.Text = button2.Text;
                button2.Text = tmp;
            }

            if (button3.Text == "")
            {
                tmp = button3.Text;
                button3.Text = button2.Text;
                button2.Text = tmp;
            }

            if (button6.Text == "")
            {
                tmp = button6.Text;
                button6.Text = button2.Text;
                button2.Text = tmp;
            }
            Finish(button1, button2, button3, button4, button5, button6, button7, button8, button9, button10, button11, button12, button13, button14, button15, button16);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Button3();

            if (button2.Text == "")
            {
                tmp = button2.Text;
                button2.Text = button3.Text;
                button3.Text = tmp;
            }

            if (button4.Text == "")
            {
                tmp = button4.Text;
                button4.Text = button3.Text;
                button3.Text = tmp;
            }

            if (button7.Text == "")
            {
                tmp = button7.Text;
                button7.Text = button3.Text;
                button3.Text = tmp;
            }
            Finish(button1, button2, button3, button4, button5, button6, button7, button8, button9, button10, button11, button12, button13, button14, button15, button16);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Button4();

            if (button3.Text == "")
            {
                tmp = button3.Text;
                button3.Text = button4.Text;
                button4.Text = tmp;
            }

            if (button8.Text == "")
            {
                tmp = button8.Text;
                button8.Text = button4.Text;
                button4.Text = tmp;
            }

            Finish(button1, button2, button3, button4, button5, button6, button7, button8, button9, button10, button11, button12, button13, button14, button15, button16);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Button5();

            if (button1.Text == "")
            {
                tmp = button1.Text;
                button1.Text = button5.Text;
                button5.Text = tmp;
            }
            
            if (button6.Text == "")
            {
                tmp = button6.Text;
                button6.Text = button5.Text;
                button5.Text = tmp;
            }

            if (button9.Text == "")
            {
                tmp = button9.Text;
                button9.Text = button5.Text;
                button5.Text = tmp;
            }
           
            Finish(button1, button2, button3, button4, button5, button6, button7, button8, button9, button10, button11, button12, button13, button14, button15, button16);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Button6();

            if (button2.Text == "")
            {
                tmp = button2.Text;
                button2.Text = button6.Text;
                button6.Text = tmp;
            }
            
            if (button5.Text == "")
            {
                tmp = button5.Text;
                button5.Text = button6.Text;
                button6.Text = tmp;
            }

            if (button7.Text == "")
            {
                tmp = button7.Text;
                button7.Text = button6.Text;
                button6.Text = tmp;
            }

            if (button10.Text == "")
            {
                tmp = button10.Text;
                button10.Text = button6.Text;
                button6.Text = tmp;
            }
            Finish(button1, button2, button3, button4, button5, button6, button7, button8, button9, button10, button11, button12, button13, button14, button15, button16);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Button7();

            if (button3.Text == "")
            {
                tmp = button3.Text;
                button3.Text = button7.Text;
                button7.Text = tmp;
            }

            if (button6.Text == "")
            {
                tmp = button6.Text;
                button6.Text = button7.Text;
                button7.Text = tmp;
            }

            if (button8.Text == "")
            {
                tmp = button8.Text;
                button8.Text = button7.Text;
                button7.Text = tmp;
            }

            if (button11.Text == "")
            {
                tmp = button11.Text;
                button11.Text = button7.Text;
                button7.Text = tmp;
            }
            Finish(button1, button2, button3, button4, button5, button6, button7, button8, button9, button10, button11, button12, button13, button14, button15, button16);        
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Button8();


            if (button4.Text == "")
            {
                tmp = button4.Text;
                button4.Text = button8.Text;
                button8.Text = tmp;
            }

            if (button7.Text == "")
            {
                tmp = button7.Text;
                button7.Text = button8.Text;
                button8.Text = tmp;
            }
            
            if (button12.Text == "")
            {
                tmp = button12.Text;
                button12.Text = button8.Text;
                button8.Text = tmp;
            }
            Finish(button1, button2, button3, button4, button5, button6, button7, button8, button9, button10, button11, button12, button13, button14, button15, button16);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Button9();

            if (button5.Text == "")
            {
                tmp = button5.Text;
                button5.Text = button9.Text;
                button9.Text = tmp;
            }

            if (button10.Text == "")
            {
                tmp = button10.Text;
                button10.Text = button9.Text;
                button9.Text = tmp;
            }

            if (button13.Text == "")
            {
                tmp = button13.Text;
                button13.Text = button9.Text;
                button9.Text = tmp;
            }

            Finish(button1, button2, button3, button4, button5, button6, button7, button8, button9, button10, button11, button12, button13, button14, button15, button16);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Button10();

            if (button6.Text == "")
            {
                tmp = button6.Text;
                button6.Text = button10.Text;
                button10.Text = tmp;
            }

            if (button9.Text == "")
            {
                tmp = button9.Text;
                button9.Text = button10.Text;
                button10.Text = tmp;
            }

            if (button11.Text == "")
            {
                tmp = button11.Text;
                button11.Text = button10.Text;
                button10.Text = tmp;
            }

            if (button14.Text == "")
            {
                tmp = button14.Text;
                button14.Text = button10.Text;
                button10.Text = tmp;
            }

            Finish(button1, button2, button3, button4, button5, button6, button7, button8, button9, button10, button11, button12, button13, button14, button15, button16);
        
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Button11();

            if (button7.Text == "")
            {
                tmp = button7.Text;
                button7.Text = button11.Text;
                button11.Text = tmp;
            }

            if (button10.Text == "")
            {
                tmp = button10.Text;
                button10.Text = button11.Text;
                button11.Text = tmp;
            }

            if (button12.Text == "")
            {
                tmp = button12.Text;
                button12.Text = button11.Text;
                button11.Text = tmp;
            }

            if (button15.Text == "")
            {
                tmp = button15.Text;
                button15.Text = button11.Text;
                button11.Text = tmp;
            }

            Finish(button1, button2, button3, button4, button5, button6, button7, button8, button9, button10, button11, button12, button13, button14, button15, button16);
        
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Button12();

            if (button8.Text == "")
            {
                tmp = button8.Text;
                button8.Text = button12.Text;
                button12.Text = tmp;
            }

            if (button11.Text == "")
            {
                tmp = button11.Text;
                button11.Text = button12.Text;
                button12.Text = tmp;
            }

            if (button16.Text == "")
            {
                tmp = button16.Text;
                button16.Text = button12.Text;
                button12.Text = tmp;
            }

            Finish(button1, button2, button3, button4, button5, button6, button7, button8, button9, button10, button11, button12, button13, button14, button15, button16);
        
        }

        private void button13_Click(object sender, EventArgs e)
        {
            Button13();

            if (button9.Text == "")
            {
                tmp = button9.Text;
                button9.Text = button13.Text;
                button13.Text = tmp;
            }

            if (button14.Text == "")
            {
                tmp = button14.Text;
                button14.Text = button13.Text;
                button13.Text = tmp;
            }

            Finish(button1, button2, button3, button4, button5, button6, button7, button8, button9, button10, button11, button12, button13, button14, button15, button16);
        
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Button14();

            if (button10.Text == "")
            {
                tmp = button10.Text;
                button10.Text = button14.Text;
                button14.Text = tmp;
            }

            if (button13.Text == "")
            {
                tmp = button13.Text;
                button13.Text = button14.Text;
                button14.Text = tmp;
            }

            if (button15.Text == "")
            {
                tmp = button15.Text;
                button15.Text = button14.Text;
                button14.Text = tmp;
            }

            Finish(button1, button2, button3, button4, button5, button6, button7, button8, button9, button10, button11, button12, button13, button14, button15, button16);
        
        }

        private void button15_Click(object sender, EventArgs e)
        {
            Button15();

            if (button11.Text == "")
            {
                tmp = button11.Text;
                button11.Text = button15.Text;
                button15.Text = tmp;
            }

            if (button14.Text == "")
            {
                tmp = button14.Text;
                button14.Text = button15.Text;
                button15.Text = tmp;
            }

            if (button16.Text == "")
            {
                tmp = button16.Text;
                button16.Text = button15.Text;
                button15.Text = tmp;
            }

            Finish(button1, button2, button3, button4, button5, button6, button7, button8, button9, button10, button11, button12, button13, button14, button15, button16);
        
        }

        private void button16_Click(object sender, EventArgs e)
        {
            Button16();

            if (button12.Text == "")
            {
                tmp = button12.Text;
                button12.Text = button16.Text;
                button16.Text = tmp;
            }

            if (button15.Text == "")
            {
                tmp = button15.Text;
                button15.Text = button16.Text;
                button16.Text = tmp;
            }

            Finish(button1, button2, button3, button4, button5, button6, button7, button8, button9, button10, button11, button12, button13, button14, button15, button16);
        
        }

        private void Game_Load(object sender, EventArgs e)
        {

        }

        
    }
}
